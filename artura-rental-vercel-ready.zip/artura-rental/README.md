# LuxeMotion — McLaren Artura Rental (Vercel‑Ready)

A production‑ready, single‑page **React + Vite + Tailwind** site showcasing a 2023 **McLaren Artura** rental.

## 🚀 One‑click deploy to Vercel (recommended)
1. Push this folder to a new GitHub repo (e.g. `artura-rental`).
2. Go to https://vercel.com → **New Project** → **Import GitHub Repo**.
3. Framework Preset: **Vite** (auto‑detected). Build command: `vite build`. Output dir: `dist`.
4. Click **Deploy**. Your site goes live at a *.vercel.app domain.
5. (Optional) Add a custom domain in the Vercel dashboard.

## 🖥️ Run locally
```bash
npm install
npm run dev
# open the printed localhost URL
```

## 🧰 Tech stack
- React + Vite
- Tailwind CSS
- framer-motion
- lucide-react

## 📁 Project structure
```
artura-rental/
  ├─ index.html
  ├─ package.json
  ├─ postcss.config.js
  ├─ tailwind.config.js
  ├─ vite.config.js
  └─ src/
     ├─ App.jsx
     ├─ index.css
     └─ main.jsx
```

## 🖼️ Images
Replace the stock Unsplash image URLs inside `src/App.jsx` with your own vehicle photos before launch.

## 🔐 Notes
- Pricing/fees and the quote calculator are sample values—adjust to your business.
- The booking form currently **alerts** a JSON summary. Connect it to email/DB/API for production.
